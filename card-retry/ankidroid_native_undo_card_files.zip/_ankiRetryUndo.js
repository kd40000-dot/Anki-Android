(() => {
    "use strict";

    // How long the corrected answer stays visible after a wrong attempt.
    const WRONG_ANSWER_VISIBLE_MS = 1600;

    // Brief confirmation when a retried answer is finally correct.
    const RETRY_CORRECT_VISIBLE_MS = 250;

    // Give the next question render a moment to settle before native Undo.
    const UNDO_AFTER_RENDER_MS = 100;

    const STATE_KEY = "stf_native_undo_retry_v1";
    const TYPED_KEY = "stf_typedInput";

    function sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    function loadState() {
        try {
            const raw = sessionStorage.getItem(STATE_KEY);
            return raw ? JSON.parse(raw) : null;
        } catch (_) {
            return null;
        }
    }

    function saveState(state) {
        sessionStorage.setItem(STATE_KEY, JSON.stringify(state));
    }

    function clearState() {
        sessionStorage.removeItem(STATE_KEY);
    }

    function clearTypedAnswer() {
        sessionStorage.removeItem(TYPED_KEY);
    }

    function getApi() {
        if (typeof AnkiDroidJS === "undefined") {
            return null;
        }

        return AnkiDroidJS.init({
            version: "0.0.3",
            developer: "local-native-undo-retry"
        });
    }

    function resultValue(result) {
        return result && result.success === true ? result.value : null;
    }

    async function getCardId(api) {
        const result = await api.ankiGetCardId();
        const value = resultValue(result);
        return value == null ? null : String(value);
    }

    async function stillOnCard(api, expectedCardId) {
        try {
            return (await getCardId(api)) === String(expectedCardId);
        } catch (_) {
            return false;
        }
    }

    async function handleQuestionSide(api) {
        const state = loadState();

        if (!state || !state.pendingUndo) {
            return;
        }

        // Clear this BEFORE undoing. The restored question runs this script again,
        // and must not immediately undo a second time.
        state.pendingUndo = false;
        saveState(state);
        clearTypedAnswer();

        if (!api || typeof api.ankiUndo !== "function") {
            console.warn("Native retry: ankiUndo() is unavailable. Use the modified AnkiDroid build.");
            clearState();
            return;
        }

        await sleep(UNDO_AFTER_RENDER_MS);

        try {
            const result = await api.ankiUndo();
            if (resultValue(result) !== true) {
                console.warn("Native retry: Undo was not accepted.", result);
                clearState();
            }
        } catch (error) {
            console.error("Native retry: Undo failed.", error);
            clearState();
        }
    }

    async function handleSmarterTypeResult(api, correct) {
        if (!api || typeof api.ankiGetCardId !== "function") {
            return;
        }

        let cardId;
        try {
            cardId = await getCardId(api);
        } catch (error) {
            console.error("Native retry: could not get card ID.", error);
            return;
        }

        if (cardId == null) {
            return;
        }

        const state = loadState();
        const isRetryOfThisCard =
            !!state &&
            state.failed === true &&
            String(state.cardId) === cardId;

        clearTypedAnswer();

        // Correct on the very first attempt: completely normal AnkiDroid behaviour.
        if (correct && !isRetryOfThisCard) {
            // Remove a stale state if it somehow points at this card.
            if (state && String(state.cardId) === cardId) {
                clearState();
            }
            return;
        }

        // Once a previously failed card is finally correct, record one real Again
        // and DO NOT undo it.
        if (correct && isRetryOfThisCard) {
            await sleep(RETRY_CORRECT_VISIBLE_MS);

            if (!(await stillOnCard(api, cardId))) {
                return;
            }

            clearState();

            try {
                await api.ankiAnswerEase1();
            } catch (error) {
                console.error("Native retry: final Again failed.", error);
            }
            return;
        }

        // Wrong answer. Do not automatically rate anything unless the custom build
        // exposes native Undo; otherwise we could advance the card with no way back.
        if (typeof api.ankiUndo !== "function") {
            console.warn("Native retry: wrong answer detected, but ankiUndo() is unavailable.");
            return;
        }

        // Leave the Smart Type Field correction visible long enough to read it.
        await sleep(WRONG_ANSWER_VISIBLE_MS);

        // If the user manually rated/left the card during the delay, abort safely.
        if (!(await stillOnCard(api, cardId))) {
            return;
        }

        saveState({
            cardId,
            failed: true,
            pendingUndo: true
        });

        try {
            await api.ankiAnswerEase1();
        } catch (error) {
            console.error("Native retry: automatic Again failed.", error);
            clearState();
        }
    }

    const api = getApi();
    const isAnswerSide = !!document.getElementById("answer");

    if (!isAnswerSide) {
        handleQuestionSide(api);
        return;
    }

    let handled = false;

    document.addEventListener("smarterTypeFieldResult", event => {
        if (handled) {
            return;
        }

        const value = event.detail && event.detail.correct;
        if (typeof value !== "boolean") {
            return;
        }

        handled = true;
        handleSmarterTypeResult(api, value);
    });
})();
