(()=>{
"use strict";

function e(){}

function n(e,n,t,o,s){
    for(var r=0,i=n.length,u=0,a=0;r<i;r++){
        var c=n[r];

        if(c.removed){
            if(
                c.value=e.join(o.slice(a,a+c.count)),
                a+=c.count,
                r&&n[r-1].added
            ){
                var l=n[r-1];
                n[r-1]=n[r];
                n[r]=l
            }
        }else{
            if(!c.added&&s){
                var p=t.slice(u,u+c.count);

                p=p.map((function(e,n){
                    var t=o[a+n];
                    return t.length>e.length?t:e
                }));

                c.value=e.join(p)
            }else{
                c.value=e.join(t.slice(u,u+c.count))
            }

            u+=c.count;
            c.added||(a+=c.count)
        }
    }

    var f=n[i-1];

    return i>1&&
        "string"==typeof f.value&&
        (f.added||f.removed)&&
        e.equals("",f.value)&&
        (n[i-2].value+=f.value,n.pop()),
        n
}

e.prototype={
    diff:function(e,t){
        var o=arguments.length>2&&void 0!==arguments[2]
            ?arguments[2]
            :{},
            s=o.callback;

        "function"==typeof o&&(s=o,o={});

        this.options=o;

        var r=this;

        function i(e){
            return s
                ?(setTimeout((function(){s(void 0,e)}),0),!0)
                :e
        }

        e=this.castInput(e);
        t=this.castInput(t);

        e=this.removeEmpty(this.tokenize(e));

        var u=(t=this.removeEmpty(this.tokenize(t))).length,
            a=e.length,
            c=1,
            l=u+a;

        o.maxEditLength&&(l=Math.min(l,o.maxEditLength));

        var p=[{newPos:-1,components:[]}],
            f=this.extractCommon(p[0],t,e,0);

        if(p[0].newPos+1>=u&&f+1>=a)
            return i([{value:this.join(t),count:t.length}]);

        function d(){
            for(var o=-1*c;o<=c;o+=2){
                var s=void 0,
                    l=p[o-1],
                    f=p[o+1],
                    d=(f?f.newPos:0)-o;

                l&&(p[o-1]=void 0);

                var h=l&&l.newPos+1<u,
                    g=f&&0<=d&&d<a;

                if(h||g){
                    if(
                        !h||g&&l.newPos<f.newPos
                            ?(
                                s={
                                    newPos:(v=f).newPos,
                                    components:v.components.slice(0)
                                },
                                r.pushComponent(s.components,void 0,!0)
                            )
                            :(
                                (s=l).newPos++,
                                r.pushComponent(s.components,!0,void 0)
                            ),
                        d=r.extractCommon(s,t,e,o),
                        s.newPos+1>=u&&d+1>=a
                    )
                        return i(n(r,s.components,t,e,r.useLongestToken));

                    p[o]=s
                }else{
                    p[o]=void 0
                }
            }

            var v;
            c++
        }

        if(s){
            !function e(){
                setTimeout((function(){
                    if(c>l)return s();
                    d()||e()
                }),0)
            }()
        }else{
            for(;c<=l;){
                var h=d();
                if(h)return h
            }
        }
    },

    pushComponent:function(e,n,t){
        var o=e[e.length-1];

        o&&o.added===n&&o.removed===t
            ?e[e.length-1]={
                count:o.count+1,
                added:n,
                removed:t
            }
            :e.push({
                count:1,
                added:n,
                removed:t
            })
    },

    extractCommon:function(e,n,t,o){
        for(
            var s=n.length,
                r=t.length,
                i=e.newPos,
                u=i-o,
                a=0;
            i+1<s&&
            u+1<r&&
            this.equals(n[i+1],t[u+1]);
        )
            i++,u++,a++;

        return a&&e.components.push({count:a}),
            e.newPos=i,
            u
    },

    equals:function(e,n){
        return this.options.comparator
            ?this.options.comparator(e,n)
            :e===n||
             this.options.ignoreCase&&
             e.toLowerCase()===n.toLowerCase()
    },

    removeEmpty:function(e){
        for(var n=[],t=0;t<e.length;t++)
            e[t]&&n.push(e[t]);

        return n
    },

    castInput:function(e){
        return e
    },

    tokenize:function(e){
        return e.split("")
    },

    join:function(e){
        return e.join("")
    }
};

var t=new e,
    o=/^[A-Za-z\xC0-\u02C6\u02C8-\u02D7\u02DE-\u02FF\u1E00-\u1EFF]+$/,
    s=/\S/,
    r=new e;

r.equals=function(e,n){
    return this.options.ignoreCase&&(
        e=e.toLowerCase(),
        n=n.toLowerCase()
    ),
    e===n||
    this.options.ignoreWhitespace&&
    !s.test(e)&&
    !s.test(n)
};

r.tokenize=function(e){
    for(
        var n=e.split(/([^\S\r\n]+|[()[\]{}'"\r\n]|\b)/),
            t=0;
        t<n.length-1;
        t++
    )
        !n[t+1]&&
        n[t+2]&&
        o.test(n[t])&&
        o.test(n[t+2])&&(
            n[t]+=n[t+2],
            n.splice(t+1,2),
            t--
        );

    return n
};

var i=new e;

function u(e){
    return u=
        "function"==typeof Symbol&&
        "symbol"==typeof Symbol.iterator
            ?function(e){return typeof e}
            :function(e){
                return e&&
                    "function"==typeof Symbol&&
                    e.constructor===Symbol&&
                    e!==Symbol.prototype
                        ?"symbol"
                        :typeof e
            },
    u(e)
}

i.tokenize=function(e){
    var n=[],
        t=e.split(/(\n|\r\n)/);

    t[t.length-1]||t.pop();

    for(var o=0;o<t.length;o++){
        var s=t[o];

        o%2&&!this.options.newlineIsToken
            ?n[n.length-1]+=s
            :(
                this.options.ignoreWhitespace&&(s=s.trim()),
                n.push(s)
            )
    }

    return n
};

(new e).tokenize=function(e){
    return e.split(/(\S.+?[.!?])(?=\s+|$)/)
};

(new e).tokenize=function(e){
    return e.split(/([{}:;,]|\s+)/)
};

var a=Object.prototype.toString,
    c=new e;

function l(e,n,t,o,s){
    var r,i;

    for(
        n=n||[],
        t=t||[],
        o&&(e=o(s,e)),
        r=0;
        r<n.length;
        r+=1
    )
        if(n[r]===e)
            return t[r];

    if("[object Array]"===a.call(e)){
        for(
            n.push(e),
            i=new Array(e.length),
            t.push(i),
            r=0;
            r<e.length;
            r+=1
        )
            i[r]=l(e[r],n,t,o,s);

        return n.pop(),
            t.pop(),
            i
    }

    if(e&&e.toJSON&&(e=e.toJSON()),"object"===u(e)&&null!==e){
        n.push(e);
        i={};
        t.push(i);

        var c,p=[];

        for(c in e)
            e.hasOwnProperty(c)&&p.push(c);

        for(
            p.sort(),
            r=0;
            r<p.length;
            r+=1
        )
            i[c=p[r]]=l(e[c],n,t,o,c);

        n.pop();
        t.pop()
    }else{
        i=e
    }

    return i
}

c.useLongestToken=!0;
c.tokenize=i.tokenize;

c.castInput=function(e){
    var n=this.options,
        t=n.undefinedReplacement,
        o=n.stringifyReplacer,
        s=void 0===o
            ?function(e,n){
                return void 0===n?t:n
            }
            :o;

    return "string"==typeof e
        ?e
        :JSON.stringify(l(e,null,null,s),s,"  ")
};

c.equals=function(n,t){
    return e.prototype.equals.call(
        c,
        n.replace(/,([\r\n])/g,"$1"),
        t.replace(/,([\r\n])/g,"$1")
    )
};

var p=new e;


/* ---------------------------------------------------------
   SmarterTypeField helpers
   --------------------------------------------------------- */

function f(e){
    return [...e]
        .map((e=>
            e.textContent
                .replace(/\u00a0(?=\p{M})/gu,"")
        ))
        .join("")
        .trim()
}

function d(e){
    return /[\p{P}$+<=>^|~]/u.test(e)
}

function h(e){
    let n=[],
        t="";

    for(let o=0;o<e.length;o++){
        d(e[o])
            ?(
                t&&n.push(t),
                n.push(e[o]),
                t=""
            )
            :t+=e[o]
    }

    return t&&n.push(t),
        n
}


/* ---------------------------------------------------------
   MULTIPLE ANSWER PATCH
   ---------------------------------------------------------

   A Back field such as:

       hello|hi|greetings

   becomes three valid answers:

       hello
       hi
       greetings

   The original complete list is retained for display.
   --------------------------------------------------------- */

function normalizeAlternative(value,config){
    let result=value.trim();

    if(config.ignore_accents){
        result=result
            .normalize("NFD")
            .replace(/\p{M}/gu,"")
    }

    if(config.ignore_case){
        result=result.toLowerCase()
    }

    if(config.ignore_punctuations){
        result=[...result]
            .filter(ch=>!d(ch))
            .join("")
    }

    return result
}


function alternativeIsAccepted(typed,answer,config){
    const normalizedTyped=normalizeAlternative(typed,config);
    const normalizedAnswer=normalizeAlternative(answer,config);

    if(normalizedTyped===normalizedAnswer)
        return true;

    if(
        config.ignore_extra_words &&
        normalizedAnswer.length>0
    ){
        const escaped=normalizedAnswer.replace(
            /[.*+?^${}()|[\]\\]/g,
            "\\$&"
        );

        const flags=config.ignore_case?"i":"";

        if(new RegExp(escaped,flags).test(normalizedTyped))
            return true
    }

    return false
}


function diffScore(typed,answer,config){
    let left=typed;
    let right=answer;

    if(config.ignore_accents){
        left=left.normalize("NFD").replace(/\p{M}/gu,"");
        right=right.normalize("NFD").replace(/\p{M}/gu,"")
    }

    if(config.ignore_case){
        left=left.toLowerCase();
        right=right.toLowerCase()
    }

    if(config.ignore_punctuations){
        left=[...left].filter(ch=>!d(ch)).join("");
        right=[...right].filter(ch=>!d(ch)).join("")
    }

    const result=t.diff(
        left,
        right,
        config.ignore_case
            ?{ignoreCase:true}
            :{}
    );

    if(!result)
        return Infinity;

    return result.reduce(
        (score,part)=>
            score+
            (
                part.added||part.removed
                    ?(part.count||part.value?.length||1)
                    :0
            ),
        0
    )
}


function renderAllAlternatives(answers, matchedAnswer){
    return answers
        .map(answer=>
            answer === matchedAnswer
                ? `<span class="typeGood">${answer}</span>`
                : `<span>${answer}</span>`
        )
        .join(" | ")
}


/* ---------------------------------------------------------
   Main SmarterTypeField comparison
   --------------------------------------------------------- */

function reportSmarterTypeFieldResult(correct){
    document.dispatchEvent(
        new CustomEvent(
            "smarterTypeFieldResult",
            {detail:{correct:!!correct}}
        )
    )
}

function g(e){

    const answerBox=document.querySelector("code#typeans");

    if(!answerBox)
        return;

    /* Exact native matches may not contain #typearrow. */
    if(!document.querySelector("span#typearrow")){
        reportSmarterTypeFieldResult(
            !answerBox.querySelector(".typeBad")
        );
        return
    }

    const n="code#typeans",
          o=`${n} > span[class^="type"]`,
          s=`${n} br ~ span[class^="type"]`,
          r=[...document.querySelectorAll(o)],
          i=[...document.querySelectorAll(s)],
          u=r.filter(
              e=>
                  !i.includes(e)&&
                  !e.classList.contains("typeMissed")
          ),
          a=answerBox,

          /* What the user actually typed */
          typed=
              sessionStorage
                  .getItem("stf_typedInput")
                  ?.trim()
              ??f(u),

          /* Full Back field, including | alternatives */
          fullAnswer=f(i);


    console.log("Full entry:",typed);
    console.log("Full answer:",fullAnswer);


    /* Split the Back field on |.

       A normal Back field without | simply produces
       a one-item array, so existing cards continue
       to behave normally.
    */

    const alternatives=fullAnswer
        .split("|")
        .map(x=>x.trim())
        .filter(Boolean);


    /*
       First check whether the typed value is accepted
       by ANY alternative.
    */

    const acceptedAlternative=alternatives.find(
        answer=>alternativeIsAccepted(
            typed,
            answer,
            e
        )
    );


    /*
       CORRECT ANSWER

       Render every alternative as typeGood.

       This is important for your existing back-template
       script because it looks for .typeBad / .typeGood.
    */

    if(acceptedAlternative){

        console.log(
            "Matched alternative:",
            acceptedAlternative
        );

        a.innerHTML=
    renderAllAlternatives(
        alternatives,
        acceptedAlternative
    );

        reportSmarterTypeFieldResult(true);
        return
    }


    /*
       WRONG ANSWER

       Find the closest alternative so SmarterTypeField
       gives a useful diff rather than comparing against
       the entire:

           hello|hi|greetings

       string.
    */

    let selectedAnswer=alternatives[0]||fullAnswer;
    let bestScore=Infinity;

    for(const alternative of alternatives){

        const score=diffScore(
            typed,
            alternative,
            e
        );

        if(score<bestScore){
            bestScore=score;
            selectedAnswer=alternative
        }
    }


    console.log(
        "Closest alternative:",
        selectedAnswer
    );


    /*
       From here this is the normal SmarterTypeField
       comparison, but against selectedAnswer rather
       than the complete | separated field.
    */

    const p=e.ignore_case
        ?{ignoreCase:!0}
        :{};

    let diffResult,
        normalizedEntry=typed,
        normalizedAnswer=selectedAnswer;


    if(e.ignore_accents){

        normalizedEntry=typed
            .normalize("NFD")
            .replace(/\p{M}/gu,"");

        normalizedAnswer=selectedAnswer
            .normalize("NFD")
            .replace(/\p{M}/gu,"")
    }


    console.log(
        "Normalized entry:",
        normalizedEntry
    );

    console.log(
        "Normalized answer:",
        normalizedAnswer
    );


    if(e.ignore_extra_words){

        let entryForExtra=normalizedEntry,
            answerForExtra=normalizedAnswer;

        if(e.ignore_punctuations){

            const removePunctuation=e=>
                e
                    .split("")
                    .filter(e=>!d(e))
                    .join("");

            entryForExtra=
                removePunctuation(entryForExtra);

            answerForExtra=
                removePunctuation(answerForExtra)
        }


        if(
            answerForExtra.length>0 &&
            entryForExtra!==answerForExtra
        ){

            const escaped=
                answerForExtra.replace(
                    /[.*+?^${}()|[\]\\]/g,
                    "\\$&"
                );

            const flags=
                e.ignore_case
                    ?"i"
                    :"";

            new RegExp(
                escaped,
                flags
            ).test(entryForExtra)&&(
                diffResult=[
                    {value:selectedAnswer}
                ]
            )
        }
    }


    if(!diffResult){

        let left=e.ignore_accents
            ?normalizedEntry
            :typed;

        let right=e.ignore_accents
            ?normalizedAnswer
            :selectedAnswer;

        diffResult=t.diff(
            left,
            right,
            p
        );


        if(e.ignore_punctuations){

            const rebuilt=[];

            for(const part of diffResult){

                if(!part.value)
                    continue;

                if(
                    !part.value
                        .split("")
                        .some(d)
                ){
                    rebuilt.push(part);
                    continue
                }

                if(
                    part.value
                        .split("")
                        .every(e=>d(e))
                ){
                    rebuilt.push(part);
                    continue
                }

                const pieces=h(part.value);

                pieces.length>1
                    ?pieces.forEach(piece=>{
                        let copy={...part};
                        copy.value=piece;
                        rebuilt.push(copy)
                    })
                    :rebuilt.push(part)
            }

            diffResult=rebuilt
        }
    }


    /*
       If SmarterTypeField itself concludes that the
       comparison is completely good, show every
       alternative.
    */

    if(1===diffResult.length){

        a.innerHTML=
            renderAllAlternatives(alternatives);

        reportSmarterTypeFieldResult(true);
        return
    }


    /*
       Build the normal wrong-answer diff.
    */

    const typedParts=[],
          answerParts=[],
          typedChars=typed.split("");

    let answerOffset=0,
        accentMap=null;


    if(e.ignore_accents){

        const combining=/\p{M}/u,
              indexes=[];

        for(
            let index=0;
            index<selectedAnswer.length;
            index++
        ){
            if(!combining.test(selectedAnswer[index]))
                indexes.push(index)
        }

        indexes.push(selectedAnswer.length);

        accentMap=indexes
    }


    diffResult.forEach(part=>{

        let typedClass=
                part.added
                    ?"typeMissed"
                    :part.removed
                        ?"typeBad"
                        :"typeGood",

            answerClass=
                part.added
                    ?"typeBad"
                    :part.removed
                        ?"typeMissed"
                        :"typeGood",

            typedHtml="",
            answerHtml="";


        if("typeMissed"===typedClass){

            if(
                !(
                    e.ignore_punctuations &&
                    d(part.value)
                )
            ){
                if(
                    !(
                        typedParts.length>0 &&
                        typedParts
                            .at(-1)
                            .includes("typeBad")
                    )
                ){
                    typedHtml=
                        '<span class="typeMissed">-</span>'
                            .repeat(part.value.length)
                }
            }

        }else{

            typedHtml=
                e.ignore_punctuations &&
                d(part.value)

                    ?`<span class="typeGood">${
                        typedChars
                            .splice(
                                0,
                                part.value.length
                            )
                            .join("")
                    }</span>`

                    :`<span class="${typedClass}">${
                        typedChars
                            .splice(
                                0,
                                part.value.length
                            )
                            .join("")
                    }</span>`
        }


        if("typeMissed"!==answerClass){

            if(
                e.ignore_punctuations &&
                d(part.value)
            ){

                answerHtml=
                    `<span class="typeGood">${part.value}</span>`;

            }else if(e.ignore_accents){

                const start=
                    accentMap[answerOffset];

                const end=
                    accentMap[
                        answerOffset+
                        part.value.length
                    ];

                answerHtml=
                    `<span class="${answerClass}">${
                        selectedAnswer.slice(
                            start,
                            end
                        )
                    }</span>`;

            }else{

                answerHtml=
                    `<span class="${answerClass}">${part.value}</span>`
            }

            answerOffset+=part.value.length
        }


        typedParts.push(typedHtml);
        answerParts.push(answerHtml)
    });


    /*
       If everything wound up good after SmarterTypeField's
       normal processing, show all alternatives.
    */

    if(
    answerParts.every(
        e=>e.includes("typeGood")
    )
){

    a.innerHTML=
        renderAllAlternatives(
            alternatives,
            selectedAnswer
        );

    reportSmarterTypeFieldResult(true);

}else{

        const typedDiff=
            v(typedParts.join(""));

        const answerDiff=
            v(answerParts.join(""));

        /*
           Keep the normal diff against the closest answer,
           then show the complete list underneath.

           The alternatives underneath intentionally do not
           receive typeBad/typeGood classes, so they don't
           interfere with your ANKI_WRONG marker detection.
        */

        const allAnswers=
            alternatives.join(" | ");

        a.innerHTML=
            `${typedDiff}`+
            `<br>`+
            `<span id="typearrow">⇩</span>`+
            `<br>`+
            `${answerDiff}`+
            `<br>`+
            `<span class="stf-alternatives">${allAnswers}</span>`;

        reportSmarterTypeFieldResult(false)
    }
}


/* ---------------------------------------------------------
   Original span-merging helper
   --------------------------------------------------------- */

function v(e){

    const n=[],
          t=/<span class="(type\w+)">([\s\S]*?)<\/span>/g;

    let o;

    for(;null!==(o=t.exec(e));){

        const[,e,t]=o,
              s=n[n.length-1];

        s&&s.cls===e
            ?s.text+=t
            :n.push({
                cls:e,
                text:t
            })
    }

    return n
        .map(
            ({cls:e,text:n})=>
                `<span class="${e}">${n}</span>`
        )
        .join("")
}


/* ---------------------------------------------------------
   Original setup
   --------------------------------------------------------- */

p.tokenize=function(e){
    return e.slice()
};

p.join=p.removeEmpty=function(e){
    return e
};


var m=document.querySelector("input#typeans");

if(m){

    m.addEventListener(
        "change",
        (function(e){
            sessionStorage.setItem(
                "stf_typedInput",
                e.target.value
            )
        })
    );

}else if(window.addon_config){

    window.addon_config.enabled&&
        g(addon_config);

}else{

    var y=document
        .currentScript
        .getAttribute("data-config");

    fetch(
        "_smarterTypeField.config"
        .concat(y,".json")
    )
    .then((function(e){

        if(!e.ok)
            throw new Error(
                "Network response was not ok"
            );

        return e.json()
    }))
    .then((function(e){

        e.enabled&&g(e)

    }))
    .catch((function(e){

        addon_config={
            ignore_case:!0,
            ignore_accents:!1,
            ignore_punctuations:!1
        };

        g(addon_config);

        console.error(
            "There has been a problem with your fetch operation:",
            e
        )
    }))
}

})();